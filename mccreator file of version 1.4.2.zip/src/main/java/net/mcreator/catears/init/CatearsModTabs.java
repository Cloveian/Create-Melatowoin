/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.catears.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.catears.CatearsMod;

public class CatearsModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CatearsMod.MODID);
	public static final RegistryObject<CreativeModeTab> TAB = REGISTRY.register("tab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.catears.tab")).icon(() -> new ItemStack(CatearsModItems.BLUECATEARS_HELMET.get())).displayItems((parameters, tabData) -> {
				tabData.accept(CatearsModItems.FUR.get());
				tabData.accept(CatearsModItems.BLUECATEARS_HELMET.get());
				tabData.accept(CatearsModItems.BLUECATEARS_CHESTPLATE.get());
				tabData.accept(CatearsModItems.PLASTIC.get());
				tabData.accept(CatearsModItems.FABRIC.get());
				tabData.accept(CatearsModItems.STRINGS.get());
				tabData.accept(CatearsModItems.DUST.get());
				tabData.accept(CatearsModItems.ORANGECATEARS_HELMET.get());
				tabData.accept(CatearsModItems.ORANGECATEARS_CHESTPLATE.get());
				tabData.accept(CatearsModItems.BLACKCATEARS_HELMET.get());
				tabData.accept(CatearsModItems.BLACKCATEARS_CHESTPLATE.get());
				tabData.accept(CatearsModItems.REDCATEARS_HELMET.get());
				tabData.accept(CatearsModItems.REDCATEARS_CHESTPLATE.get());
				tabData.accept(CatearsModItems.GREENCATEARS_HELMET.get());
				tabData.accept(CatearsModItems.GREENCATEARS_CHESTPLATE.get());
			}).build());
}