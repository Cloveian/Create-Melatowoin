package net.mcreator.catears.item;

import net.minecraft.world.item.Item;

public class PlasticItem extends Item {
	public PlasticItem() {
		super(new Item.Properties());
	}
}