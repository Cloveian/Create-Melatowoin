package net.mcreator.catears.item;

import net.minecraft.world.item.Item;

public class FurItem extends Item {
	public FurItem() {
		super(new Item.Properties().stacksTo(16));
	}
}