package net.mcreator.catears.item;

import net.minecraft.world.item.Item;

public class FabricsItem extends Item {
	public FabricsItem() {
		super(new Item.Properties().stacksTo(1));
	}
}