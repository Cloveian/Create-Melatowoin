package net.mcreator.catears.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;

import net.mcreator.catears.init.CatearsModItems;

public class OrangingProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _living) {
			_living.setItemSlot(EquipmentSlot.HEAD, new ItemStack(CatearsModItems.ORANGECATEARS_HELMET.get()));
		}
		if (entity instanceof LivingEntity _living) {
			_living.setItemSlot(EquipmentSlot.CHEST, new ItemStack(CatearsModItems.ORANGECATEARS_CHESTPLATE.get()));
		}
		(entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.HEAD) : ItemStack.EMPTY).enchant(Enchantments.BINDING_CURSE, 1);
		(entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST) : ItemStack.EMPTY).enchant(Enchantments.BINDING_CURSE, 1);
	}
}