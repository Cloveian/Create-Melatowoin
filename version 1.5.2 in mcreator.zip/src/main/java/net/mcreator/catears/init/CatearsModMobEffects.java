/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.catears.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.catears.potion.EepyMobEffect;
import net.mcreator.catears.potion.ChangeMobEffect;
import net.mcreator.catears.CatearsMod;

public class CatearsModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, CatearsMod.MODID);
	public static final RegistryObject<MobEffect> EEPY = REGISTRY.register("eepy", () -> new EepyMobEffect());
	public static final RegistryObject<MobEffect> CHANGE = REGISTRY.register("change", () -> new ChangeMobEffect());
}