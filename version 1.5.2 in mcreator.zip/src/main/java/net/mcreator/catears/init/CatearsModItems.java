/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.catears.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.catears.item.*;
import net.mcreator.catears.CatearsMod;

public class CatearsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, CatearsMod.MODID);
	public static final RegistryObject<Item> FUR;
	public static final RegistryObject<Item> BLUECATEARS_HELMET;
	public static final RegistryObject<Item> BLUECATEARS_CHESTPLATE;
	public static final RegistryObject<Item> PLASTIC;
	public static final RegistryObject<Item> FABRIC;
	public static final RegistryObject<Item> FABRICS;
	public static final RegistryObject<Item> STRINGS;
	public static final RegistryObject<Item> DUST;
	public static final RegistryObject<Item> ORANGECATEARS_HELMET;
	public static final RegistryObject<Item> ORANGECATEARS_CHESTPLATE;
	public static final RegistryObject<Item> BLACKCATEARS_HELMET;
	public static final RegistryObject<Item> BLACKCATEARS_CHESTPLATE;
	public static final RegistryObject<Item> REDCATEARS_HELMET;
	public static final RegistryObject<Item> REDCATEARS_CHESTPLATE;
	public static final RegistryObject<Item> GREENCATEARS_HELMET;
	public static final RegistryObject<Item> GREENCATEARS_CHESTPLATE;
	public static final RegistryObject<Item> WHITE_CATEARS_HELMET;
	public static final RegistryObject<Item> WHITE_CATEARS_CHESTPLATE;
	public static final RegistryObject<Item> FURRYCORE;
	public static final RegistryObject<Item> BLEACH_BUCKET;
	public static final RegistryObject<Item> UNPUREFURRYNESS;
	public static final RegistryObject<Item> VINEGAR_BUCKET;
	public static final RegistryObject<Item> CA;
	public static final RegistryObject<Item> ACETONE_BUCKET;
	public static final RegistryObject<Item> CHLOROFORM_BUCKET;
	public static final RegistryObject<Item> CYANPILL;
	public static final RegistryObject<Item> ORANGPIL;
	public static final RegistryObject<Item> CYANABLE;
	public static final RegistryObject<Item> ORANGEABLE;
	public static final RegistryObject<Item> PUREFURRYNESS;
	static {
		FUR = REGISTRY.register("fur", FurItem::new);
		BLUECATEARS_HELMET = REGISTRY.register("bluecatears_helmet", BluecatearsItem.Helmet::new);
		BLUECATEARS_CHESTPLATE = REGISTRY.register("bluecatears_chestplate", BluecatearsItem.Chestplate::new);
		PLASTIC = REGISTRY.register("plastic", PlasticItem::new);
		FABRIC = REGISTRY.register("fabric", FabricItem::new);
		FABRICS = REGISTRY.register("fabrics", FabricsItem::new);
		STRINGS = REGISTRY.register("strings", StringsItem::new);
		DUST = REGISTRY.register("dust", DustItem::new);
		ORANGECATEARS_HELMET = REGISTRY.register("orangecatears_helmet", OrangecatearsItem.Helmet::new);
		ORANGECATEARS_CHESTPLATE = REGISTRY.register("orangecatears_chestplate", OrangecatearsItem.Chestplate::new);
		BLACKCATEARS_HELMET = REGISTRY.register("blackcatears_helmet", BlackcatearsItem.Helmet::new);
		BLACKCATEARS_CHESTPLATE = REGISTRY.register("blackcatears_chestplate", BlackcatearsItem.Chestplate::new);
		REDCATEARS_HELMET = REGISTRY.register("redcatears_helmet", RedcatearsItem.Helmet::new);
		REDCATEARS_CHESTPLATE = REGISTRY.register("redcatears_chestplate", RedcatearsItem.Chestplate::new);
		GREENCATEARS_HELMET = REGISTRY.register("greencatears_helmet", GreencatearsItem.Helmet::new);
		GREENCATEARS_CHESTPLATE = REGISTRY.register("greencatears_chestplate", GreencatearsItem.Chestplate::new);
		WHITE_CATEARS_HELMET = REGISTRY.register("white_catears_helmet", WhiteCatearsItem.Helmet::new);
		WHITE_CATEARS_CHESTPLATE = REGISTRY.register("white_catears_chestplate", WhiteCatearsItem.Chestplate::new);
		FURRYCORE = REGISTRY.register("furrycore", FurrycoreItem::new);
		BLEACH_BUCKET = REGISTRY.register("bleach_bucket", BleachItem::new);
		UNPUREFURRYNESS = REGISTRY.register("unpurefurryness", UnpurefurrynessItem::new);
		VINEGAR_BUCKET = REGISTRY.register("vinegar_bucket", VinegarItem::new);
		CA = REGISTRY.register("ca", CalciumacetateisveryrealItem::new);
		ACETONE_BUCKET = REGISTRY.register("acetone_bucket", AcetoneItem::new);
		CHLOROFORM_BUCKET = REGISTRY.register("chloroform_bucket", ChloroformItem::new);
		CYANPILL = REGISTRY.register("cyanpill", CyanpillItem::new);
		ORANGPIL = REGISTRY.register("orangpil", OrangpilItem::new);
		CYANABLE = REGISTRY.register("cyanable", CyanableItem::new);
		ORANGEABLE = REGISTRY.register("orangeable", OrangeableItem::new);
		PUREFURRYNESS = REGISTRY.register("purefurryness", PurefurrynessItem::new);
	}
	// Start of user code block custom items
	// End of user code block custom items
}