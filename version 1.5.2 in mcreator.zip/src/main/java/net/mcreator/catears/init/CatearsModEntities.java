/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.catears.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.catears.entity.OrangeablethrowableEntity;
import net.mcreator.catears.entity.CyanablethrowableEntity;
import net.mcreator.catears.CatearsMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class CatearsModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, CatearsMod.MODID);
	public static final RegistryObject<EntityType<CyanablethrowableEntity>> CYANABLETHROWABLE = register("cyanablethrowable", EntityType.Builder.<CyanablethrowableEntity>of(CyanablethrowableEntity::new, MobCategory.MISC)
			.setCustomClientFactory(CyanablethrowableEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<OrangeablethrowableEntity>> ORANGEABLETHROWABLE = register("orangeablethrowable", EntityType.Builder.<OrangeablethrowableEntity>of(OrangeablethrowableEntity::new, MobCategory.MISC)
			.setCustomClientFactory(OrangeablethrowableEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}
}