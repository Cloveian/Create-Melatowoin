/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.catears.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.catears.client.model.Modeltailbluemodel;
import net.mcreator.catears.client.model.Modelearnew;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class CatearsModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelearnew.LAYER_LOCATION, Modelearnew::createBodyLayer);
		event.registerLayerDefinition(Modeltailbluemodel.LAYER_LOCATION, Modeltailbluemodel::createBodyLayer);
	}
}