/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.catears.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.client.Minecraft;

import net.mcreator.catears.world.inventory.EepingMenu;
import net.mcreator.catears.world.inventory.Eeping3Menu;
import net.mcreator.catears.world.inventory.Eeping2Menu;
import net.mcreator.catears.network.MenuStateUpdateMessage;
import net.mcreator.catears.CatearsMod;

import java.util.Map;

public class CatearsModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, CatearsMod.MODID);
	public static final RegistryObject<MenuType<EepingMenu>> EEPING = REGISTRY.register("eeping", () -> IForgeMenuType.create(EepingMenu::new));
	public static final RegistryObject<MenuType<Eeping2Menu>> EEPING_2 = REGISTRY.register("eeping_2", () -> IForgeMenuType.create(Eeping2Menu::new));
	public static final RegistryObject<MenuType<Eeping3Menu>> EEPING_3 = REGISTRY.register("eeping_3", () -> IForgeMenuType.create(Eeping3Menu::new));

	public interface MenuAccessor {
		Map<String, Object> getMenuState();

		Map<Integer, Slot> getSlots();

		default void sendMenuStateUpdate(Player player, int elementType, String name, Object elementState, boolean needClientUpdate) {
			getMenuState().put(elementType + ":" + name, elementState);
			if (player instanceof ServerPlayer serverPlayer) {
				CatearsMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> serverPlayer), new MenuStateUpdateMessage(elementType, name, elementState));
			} else if (player.level().isClientSide) {
				if (Minecraft.getInstance().screen instanceof CatearsModScreens.ScreenAccessor accessor && needClientUpdate)
					accessor.updateMenuState(elementType, name, elementState);
				CatearsMod.PACKET_HANDLER.sendToServer(new MenuStateUpdateMessage(elementType, name, elementState));
			}
		}

		default <T> T getMenuState(int elementType, String name, T defaultValue) {
			try {
				return (T) getMenuState().getOrDefault(elementType + ":" + name, defaultValue);
			} catch (ClassCastException e) {
				return defaultValue;
			}
		}
	}
}