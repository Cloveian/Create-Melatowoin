/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.catears.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.catears.fluid.VinegarFluid;
import net.mcreator.catears.fluid.ChloroformFluid;
import net.mcreator.catears.fluid.BleachFluid;
import net.mcreator.catears.fluid.AcetoneFluid;
import net.mcreator.catears.CatearsMod;

public class CatearsModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, CatearsMod.MODID);
	public static final RegistryObject<FlowingFluid> BLEACH = REGISTRY.register("bleach", () -> new BleachFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_BLEACH = REGISTRY.register("flowing_bleach", () -> new BleachFluid.Flowing());
	public static final RegistryObject<FlowingFluid> VINEGAR = REGISTRY.register("vinegar", () -> new VinegarFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_VINEGAR = REGISTRY.register("flowing_vinegar", () -> new VinegarFluid.Flowing());
	public static final RegistryObject<FlowingFluid> ACETONE = REGISTRY.register("acetone", () -> new AcetoneFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_ACETONE = REGISTRY.register("flowing_acetone", () -> new AcetoneFluid.Flowing());
	public static final RegistryObject<FlowingFluid> CHLOROFORM = REGISTRY.register("chloroform", () -> new ChloroformFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_CHLOROFORM = REGISTRY.register("flowing_chloroform", () -> new ChloroformFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(BLEACH.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_BLEACH.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(VINEGAR.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_VINEGAR.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(ACETONE.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_ACETONE.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(CHLOROFORM.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_CHLOROFORM.get(), RenderType.translucent());
		}
	}
}