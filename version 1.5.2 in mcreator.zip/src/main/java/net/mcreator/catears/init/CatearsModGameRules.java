/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.catears.init;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.GameRules;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class CatearsModGameRules {
	public static final GameRules.Key<GameRules.BooleanValue> DOCAT = GameRules.register("docat", GameRules.Category.PLAYER, GameRules.BooleanValue.create(true));
}