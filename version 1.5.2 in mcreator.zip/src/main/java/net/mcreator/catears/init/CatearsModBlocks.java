/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.catears.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.catears.block.VinegarBlock;
import net.mcreator.catears.block.ChloroformBlock;
import net.mcreator.catears.block.BleachBlock;
import net.mcreator.catears.block.AcetoneBlock;
import net.mcreator.catears.CatearsMod;

public class CatearsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, CatearsMod.MODID);
	public static final RegistryObject<Block> BLEACH;
	public static final RegistryObject<Block> VINEGAR;
	public static final RegistryObject<Block> ACETONE;
	public static final RegistryObject<Block> CHLOROFORM;
	static {
		BLEACH = REGISTRY.register("bleach", BleachBlock::new);
		VINEGAR = REGISTRY.register("vinegar", VinegarBlock::new);
		ACETONE = REGISTRY.register("acetone", AcetoneBlock::new);
		CHLOROFORM = REGISTRY.register("chloroform", ChloroformBlock::new);
	}
	// Start of user code block custom blocks
	// End of user code block custom blocks
}