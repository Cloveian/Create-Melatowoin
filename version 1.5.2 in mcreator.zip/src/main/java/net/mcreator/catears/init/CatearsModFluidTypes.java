/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.catears.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.mcreator.catears.fluid.types.VinegarFluidType;
import net.mcreator.catears.fluid.types.ChloroformFluidType;
import net.mcreator.catears.fluid.types.BleachFluidType;
import net.mcreator.catears.fluid.types.AcetoneFluidType;
import net.mcreator.catears.CatearsMod;

public class CatearsModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, CatearsMod.MODID);
	public static final RegistryObject<FluidType> BLEACH_TYPE = REGISTRY.register("bleach", () -> new BleachFluidType());
	public static final RegistryObject<FluidType> VINEGAR_TYPE = REGISTRY.register("vinegar", () -> new VinegarFluidType());
	public static final RegistryObject<FluidType> ACETONE_TYPE = REGISTRY.register("acetone", () -> new AcetoneFluidType());
	public static final RegistryObject<FluidType> CHLOROFORM_TYPE = REGISTRY.register("chloroform", () -> new ChloroformFluidType());
}