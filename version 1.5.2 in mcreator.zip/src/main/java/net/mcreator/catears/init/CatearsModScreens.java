/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.catears.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import net.mcreator.catears.client.gui.EepingScreen;
import net.mcreator.catears.client.gui.Eeping3Screen;
import net.mcreator.catears.client.gui.Eeping2Screen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class CatearsModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(CatearsModMenus.EEPING.get(), EepingScreen::new);
			MenuScreens.register(CatearsModMenus.EEPING_2.get(), Eeping2Screen::new);
			MenuScreens.register(CatearsModMenus.EEPING_3.get(), Eeping3Screen::new);
		});
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}