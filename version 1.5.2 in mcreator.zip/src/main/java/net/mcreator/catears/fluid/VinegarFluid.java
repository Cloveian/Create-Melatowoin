package net.mcreator.catears.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.catears.init.CatearsModItems;
import net.mcreator.catears.init.CatearsModFluids;
import net.mcreator.catears.init.CatearsModFluidTypes;
import net.mcreator.catears.init.CatearsModBlocks;

public abstract class VinegarFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> CatearsModFluidTypes.VINEGAR_TYPE.get(), () -> CatearsModFluids.VINEGAR.get(), () -> CatearsModFluids.FLOWING_VINEGAR.get())
			.explosionResistance(100f).bucket(() -> CatearsModItems.VINEGAR_BUCKET.get()).block(() -> (LiquidBlock) CatearsModBlocks.VINEGAR.get());

	private VinegarFluid() {
		super(PROPERTIES);
	}

	public static class Source extends VinegarFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends VinegarFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}