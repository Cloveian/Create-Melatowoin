package net.mcreator.catears.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.catears.init.CatearsModItems;
import net.mcreator.catears.init.CatearsModFluids;
import net.mcreator.catears.init.CatearsModFluidTypes;
import net.mcreator.catears.init.CatearsModBlocks;

public abstract class ChloroformFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> CatearsModFluidTypes.CHLOROFORM_TYPE.get(), () -> CatearsModFluids.CHLOROFORM.get(), () -> CatearsModFluids.FLOWING_CHLOROFORM.get())
			.explosionResistance(100f).levelDecreasePerBlock(2).bucket(() -> CatearsModItems.CHLOROFORM_BUCKET.get()).block(() -> (LiquidBlock) CatearsModBlocks.CHLOROFORM.get());

	private ChloroformFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.ASH;
	}

	public static class Source extends ChloroformFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends ChloroformFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}