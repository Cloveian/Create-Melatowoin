package net.mcreator.catears.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.catears.init.CatearsModItems;
import net.mcreator.catears.init.CatearsModFluids;
import net.mcreator.catears.init.CatearsModFluidTypes;
import net.mcreator.catears.init.CatearsModBlocks;

public abstract class AcetoneFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> CatearsModFluidTypes.ACETONE_TYPE.get(), () -> CatearsModFluids.ACETONE.get(), () -> CatearsModFluids.FLOWING_ACETONE.get())
			.explosionResistance(100f).bucket(() -> CatearsModItems.ACETONE_BUCKET.get()).block(() -> (LiquidBlock) CatearsModBlocks.ACETONE.get());

	private AcetoneFluid() {
		super(PROPERTIES);
	}

	public static class Source extends AcetoneFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends AcetoneFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}