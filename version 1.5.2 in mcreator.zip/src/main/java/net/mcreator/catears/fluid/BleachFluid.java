package net.mcreator.catears.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.catears.init.CatearsModItems;
import net.mcreator.catears.init.CatearsModFluids;
import net.mcreator.catears.init.CatearsModFluidTypes;
import net.mcreator.catears.init.CatearsModBlocks;

public abstract class BleachFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> CatearsModFluidTypes.BLEACH_TYPE.get(), () -> CatearsModFluids.BLEACH.get(), () -> CatearsModFluids.FLOWING_BLEACH.get())
			.explosionResistance(100f).levelDecreasePerBlock(2).bucket(() -> CatearsModItems.BLEACH_BUCKET.get()).block(() -> (LiquidBlock) CatearsModBlocks.BLEACH.get());

	private BleachFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.ASH;
	}

	public static class Source extends BleachFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends BleachFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}