package net.mcreator.catears.potion;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeMap;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.catears.procedures.EepyEffectStartedappliedProcedure;
import net.mcreator.catears.procedures.EepyEffectExpiresProcedure;
import net.mcreator.catears.procedures.EepingThisGUIIsClosedProcedure;

public class EepyMobEffect extends MobEffect {
	public EepyMobEffect() {
		super(MobEffectCategory.HARMFUL, -16711732);
		this.addAttributeModifier(Attributes.MOVEMENT_SPEED, "5a019aba-071a-3516-afde-d6d16e5d3bee", -255, AttributeModifier.Operation.ADDITION);
	}

	@Override
	public void addAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
		super.addAttributeModifiers(entity, attributeMap, amplifier);
		EepyEffectStartedappliedProcedure.execute(entity.level(), entity.getX(), entity.getY(), entity.getZ(), entity);
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		EepingThisGUIIsClosedProcedure.execute(entity.level(), entity.getX(), entity.getY(), entity.getZ(), entity);
	}

	@Override
	public void removeAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
		super.removeAttributeModifiers(entity, attributeMap, amplifier);
		EepyEffectExpiresProcedure.execute(entity);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}