// Made with Blockbench 5.0.7
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelearnew<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "earnew"), "main");
	private final ModelPart catear;

	public Modelearnew(ModelPart root) {
		this.catear = root.getChild("catear");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition catear = partdefinition.addOrReplaceChild("catear", CubeListBuilder.create().texOffs(0, 0)
				.addBox(-4.0F, -8.0F, -1.0F, 8.0F, 4.0F, 1.0F, new CubeDeformation(0.2F)),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition cube_r1 = catear.addOrReplaceChild("cube_r1",
				CubeListBuilder.create().texOffs(12, 5)
						.addBox(-3.0F, -6.0F, 0.0F, 5.0F, 5.0F, 1.0F, new CubeDeformation(-0.4F)).texOffs(12, 11)
						.addBox(-3.0F, -6.0F, 0.0F, 5.0F, 5.0F, 1.0F, new CubeDeformation(-0.3F)),
				PartPose.offsetAndRotation(-4.0F, -10.0F, 0.0F, 3.1416F, 0.0F, -0.7854F));

		PartDefinition cube_r2 = catear.addOrReplaceChild("cube_r2",
				CubeListBuilder.create().texOffs(0, 11)
						.addBox(-3.0F, -6.0F, 0.0F, 5.0F, 5.0F, 1.0F, new CubeDeformation(-0.3F)).texOffs(0, 5)
						.addBox(-3.0F, -6.0F, 0.0F, 5.0F, 5.0F, 1.0F, new CubeDeformation(-0.4F)),
				PartPose.offsetAndRotation(5.0F, -5.0F, -1.0F, 0.0F, 0.0F, -0.7854F));

		return LayerDefinition.create(meshdefinition, 32, 32);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		catear.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {
	}
}